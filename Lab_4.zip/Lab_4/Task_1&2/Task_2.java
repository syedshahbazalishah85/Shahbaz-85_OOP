public class Task_2 {
    public static void main(String[] args) {
        Circle blue_circle = new Circle(6, "Blue");
        System.out.println("Area of Blue Circle: " + blue_circle.getArea());
    }    
}
