import java.util.Scanner;

public class task8{
	
	public static void main(String[]args){
	Scanner myObj = new Scanner(System.in);
	double mile;
	
	System.out.println("Enter Distance in Mile : ");
	mile = myObj.nextDouble();
	
	System.out.println("Distance in KM : " + (mile*1.6));


}}