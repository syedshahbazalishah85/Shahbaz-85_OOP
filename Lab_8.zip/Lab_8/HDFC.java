public class HDFC extends Bank {
    @Override
    public double getInterestRate() {
        return 4.5;
    }
}