public class Sub extends Super {
    @Override
    public void makeSound() {
        System.out.println("Animal Sound");
    }
    
    public void makeCatSound() {
        System.out.println("Cat Sound");
    }
    
    public void makeDogSound() {
        System.out.println("Dog Sound");
    }
}