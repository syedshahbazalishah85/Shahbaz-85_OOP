public class outputs{

	public static void main(String[]args){
	
	System.out.println("///////////////////");
	System.out.println("Student Points     ==");
	System.out.println("///////////////////");
	System.out.println("LAB   BONUS   TOTAL");
	System.out.println("43	    7      50");
	System.out.println("50      8      58");
	System.out.println("39     10      49");
}
}