public class ICICI extends Bank {
    @Override
    public double getInterestRate() {
        return 5.5;
    }
}