public class task3{

	public static void main(String[]args){
	String name = "Syed Shahbaz Ali";
	int age = 22;
	char grade = 'A';
	double average_GPA = 3.1;
	char gander = 'M';
	boolean foreigner = false;
	String Student_ID = "F24-0085";
	
System.out.println("NAME : " + name);
System.out.println("AGE : " + age);
System.out.println("GRADE : " + grade);
System.out.println("GPA : " + average_GPA);
System.out.println("GANDER : " + gander);
System.out.println("FOREIGNER : " + foreigner);
System.out.println("STUDETN ID : " + Student_ID);

}
}