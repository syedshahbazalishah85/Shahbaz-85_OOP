public class Task_2 {
    public static void main(String[] args) {
        Employee e1 = new Employee("Dembele", 9, 150580);
        e1.increase_Salary(2000);
        e1.Display_Details();
        e1.calculate_AnnualSalary();
    }
}
