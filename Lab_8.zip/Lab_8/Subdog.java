public class Subdog extends Super {
    @Override
    public void makeSound() {
        System.out.println("Dog Sound");
    }
}