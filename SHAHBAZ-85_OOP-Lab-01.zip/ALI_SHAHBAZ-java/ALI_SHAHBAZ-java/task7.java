import java.util.Scanner;

public class task7{
	public static void main(String[]args){
	Scanner myObj = new Scanner(System.in);
	Scanner myObj2 = new Scanner(System.in);
	double radius;
	double height;

	System.out.println("Enter RADIUS");
	radius = myObj.nextDouble();
	System.out.println("Enter HEIGHT");
	height = myObj2.nextDouble();
	
	System.out.println("Value : " + (3.14*(radius*radius)*height));
	
}
}