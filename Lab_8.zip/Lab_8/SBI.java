public class SBI extends Bank {
    @Override
    public double getInterestRate() {
        return 7.5;
    }
}