public class task4{

	public static void main(String[]args){
		

	System.out.println("THE RESULT IS : " + (10+5)*(4-6)/4);

}
}