public class Subcat extends Super {
    @Override
    public void makeSound() {
        System.out.println("Cat Sound");
    }
}