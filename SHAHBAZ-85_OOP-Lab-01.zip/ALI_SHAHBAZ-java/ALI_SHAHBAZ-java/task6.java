import java.util.Scanner;

public class task6{
	
	public static void main(String[]args){
	Scanner myObj = new Scanner(System.in);
	double number;
	
	System.out.println("Enter Dollar Currency : ");
	number = myObj.nextDouble();
	
	System.out.println("Currency in " + (number*290));
	
}
}