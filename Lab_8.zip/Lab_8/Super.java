public class Super {
    public void makeSound() {
        System.out.println("Animal Sound");
    }
}