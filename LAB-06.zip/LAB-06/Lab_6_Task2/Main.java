public class Main {
    public static void main(String[] args) {
        Graduate graduateStudent = new Graduate("Alice Smith", 30, "GS12345", "Artificial Intelligence");
        graduateStudent.displayInfo();
    }
}